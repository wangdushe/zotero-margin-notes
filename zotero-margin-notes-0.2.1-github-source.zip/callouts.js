/* Zotero 10.0.x: read-only annotation callouts anchored to PDF coordinates. */
(function (scope) {
  'use strict';
  const NS = 'http://www.w3.org/2000/svg';
  const PREF = 'extensions.margin-notes.';
  function plainComment(doc, value) {
    const template = doc.createElement('template');
    template.innerHTML = String(value || '').replace(/<br\s*\/?>/gi, '\n').replace(/<\/(?:p|div|li)>/gi, '\n');
    template.content.querySelectorAll('script,style,iframe,img,object').forEach(node => node.remove());
    return template.content.textContent.trim();
  }
  function placements(annotations) {
    const result = [];
    for (const a of annotations) {
      if (!String(a.comment || '').trim() || !Number.isInteger(a.position?.pageIndex)) continue;
      if (a.position.rects?.length) result.push({ a, pageIndex: a.position.pageIndex, rects: a.position.rects, key: a.id + ':0' });
      if (a.position.nextPageRects?.length) result.push({ a, pageIndex: a.position.pageIndex + 1, rects: a.position.nextPageRects, key: a.id + ':1' });
    }
    return result;
  }
  function stack(items, gap = 12) {
    let bottom = -Infinity;
    return items.slice().sort((a, b) => a.y - b.y || a.key.localeCompare(b.key)).map(item => {
      const top = Math.max(item.y - 16, bottom + gap);
      bottom = top + item.height;
      return { ...item, top };
    });
  }
  class MarginNotes {
    constructor(z, css, id) {
      this.z = z; this.css = css; this.id = id; this.panes = new Map(); this.running = false;
      this.onToolbar = ({ reader, doc, append }) => {
        if (!this.running || reader.type !== 'pdf') return;
        const pane = this.attach(reader, doc);
        if (!pane || pane.button?.isConnected) return;
        pane.button = this.button(pane);
        append(pane.button);
      };
    }
    button(pane) {
      const button = pane.doc.createElement('button');
      button.className = 'mn-toggle toolbar-button'; button.textContent = '连线批注';
      button.title = '显示或隐藏段落旁的连线批注';
      button.setAttribute('aria-pressed', String(pane.open));
      button.addEventListener('click', () => this.setOpen(pane, !pane.open));
      return button;
    }
    start() {
      this.running = true;
      this.z.Reader.registerEventListener('renderToolbar', this.onToolbar, this.id);
      this.scan(); this.timer = setInterval(() => this.scan(), 600);
    }
    scan() {
      if (!this.running) return;
      const readers = this.z.Reader._readers || [];
      for (const [reader, pane] of this.panes) {
        if (!readers.includes(reader) || pane.win.closed || !pane.root.isConnected) this.detach(reader);
      }
      for (const reader of readers) {
        if (reader.type !== 'pdf') continue;
        try {
          const pane = this.attach(reader, reader._iframeWindow?.document);
          if (pane?.open && !pane.doc.hidden) this.refresh(pane);
        } catch (error) { this.z.logError(error); }
      }
    }
    attach(reader, doc) {
      if (this.panes.has(reader)) return this.panes.get(reader);
      if (!doc?.body || !doc.getElementById('split-view') || !reader._internalReader) return null;
      const style = doc.createElement('style'); style.textContent = this.css; doc.head.append(style);
      const root = doc.createElement('div'); root.className = 'mn-callout-layer';
      root.setAttribute('aria-label', '段落连线批注');
      const svg = doc.createElementNS(NS, 'svg'); svg.classList.add('mn-lines'); svg.setAttribute('aria-hidden', 'true');
      const message = doc.createElement('div'); message.className = 'mn-hint';
      root.append(svg, message); doc.body.append(root);
      const pane = { reader, doc, win: doc.defaultView, style, root, svg, message,
        // New display mode starts enabled even when the old sidebar was hidden.
        open: this.z.Prefs.get(PREF + 'calloutsOpen', true) !== false,
        rows: new Map(), bindings: [], view: null, frame: null, button: null, raf: null };
      this.panes.set(reader, pane);
      pane.schedule = () => {
        if (pane.raf !== null || !pane.open) return;
        pane.raf = pane.win.requestAnimationFrame(() => { pane.raf = null; if (this.running) this.refresh(pane); });
      };
      pane.win.addEventListener('resize', pane.schedule);
      const toolbar = doc.querySelector('.toolbar .end');
      if (toolbar) { pane.button = this.button(pane); toolbar.prepend(pane.button); }
      this.setOpen(pane, pane.open, false);
      return pane;
    }
    setOpen(pane, open, persist = true) {
      pane.open = open; pane.root.hidden = !open;
      pane.doc.body.classList.toggle('mn-callouts-open', open);
      pane.doc.querySelectorAll('.mn-toggle').forEach(b => b.setAttribute('aria-pressed', String(open)));
      if (persist) this.z.Prefs.set(PREF + 'calloutsOpen', open, true);
      if (open) this.refresh(pane);
    }
    bindView(pane, view) {
      if (pane.view === view && pane.pdfWindow === view?._iframeWindow) return;
      for (const remove of pane.bindings) remove(); pane.bindings = [];
      pane.view = view; pane.pdfWindow = view?._iframeWindow;
      if (!pane.pdfWindow) return;
      const win = pane.pdfWindow;
      win.addEventListener('scroll', pane.schedule, true);
      win.addEventListener('resize', pane.schedule);
      pane.bindings.push(() => win.removeEventListener('scroll', pane.schedule, true), () => win.removeEventListener('resize', pane.schedule));
      const bus = win.PDFViewerApplication?.eventBus;
      if (bus?.on && bus?.off) for (const event of ['pagerendered', 'scalechanging', 'rotationchanging', 'updateviewarea']) {
        bus.on(event, pane.schedule); pane.bindings.push(() => bus.off(event, pane.schedule));
      }
    }
    geometry(pane, placement) {
      const view = pane.view;
      const page = pane.pdfWindow?.PDFViewerApplication?.pdfViewer?._pages?.[placement.pageIndex];
      const frame = view?._iframe || pane.pdfWindow?.frameElement;
      if (!page?.viewport || !page.div || !frame) return null;
      const r = page.div.getBoundingClientRect(), f = frame.getBoundingClientRect(), o = pane.root.getBoundingClientRect();
      // Handle PDF zoom, rotation, and CSS scaling of the frame/page.
      const fx = f.width / (frame.clientWidth || f.width || 1), fy = f.height / (frame.clientHeight || f.height || 1);
      const pageScaleX = r.width / (page.div.offsetWidth || r.width || 1);
      const pageScaleY = r.height / (page.div.offsetHeight || r.height || 1);
      const sx = (page.div.clientWidth || r.width) * pageScaleX / page.viewport.width;
      const sy = (page.div.clientHeight || r.height) * pageScaleY / page.viewport.height;
      if (![sx, sy, fx, fy].every(n => Number.isFinite(n) && n > 0)) return null;
      // This code runs in the privileged plugin compartment, while the PDF
      // viewport belongs to the content compartment. Passing a newly-created
      // plugin Array makes PDF.js fail at rect[0] (Permission denied).
      // Pass only numeric primitives; PDF.js creates its result arrays itself.
      const source = placement.rects[0];
      const first = page.viewport.convertToViewportPoint(Number(source[0]), Number(source[1]));
      const second = page.viewport.convertToViewportPoint(Number(source[2]), Number(source[3]));
      const rect = [first[0], first[1], second[0], second[1]];
      const x = f.left + (r.left + (page.div.clientLeft || 0) * pageScaleX + Math.max(rect[0], rect[2]) * sx) * fx - o.left;
      const y = f.top + (r.top + (page.div.clientTop || 0) * pageScaleY + Math.min(rect[1], rect[3]) * sy) * fy - o.top + 5;
      const right = f.left + r.right * fx - o.left;
      return { x, y, right, frameLeft: f.left - o.left, frameRight: f.right - o.left,
        pageTop: f.top + r.top * fy - o.top, pageBottom: f.top + r.bottom * fy - o.top,
        clipTop: Math.max(0, f.top - o.top), clipBottom: Math.min(o.height, f.bottom - o.top) };
    }
    refresh(pane) {
      if (!pane.open) return;
      const internal = pane.reader._internalReader, state = internal?._state;
      if (!state?.annotations) return;
      const secondary = state.primary === false && state.splitType;
      const readingMode = secondary ? state.secondaryReadingModeEnabled : state.primaryReadingModeEnabled;
      this.bindView(pane, secondary ? internal._secondaryView : internal._primaryView);
      const positions = placements(state.annotations);
      const keys = new Set(positions.map(p => p.key));
      for (const [key, row] of pane.rows) if (!keys.has(key)) {
        row.card.remove(); row.path.remove(); row.dot.remove(); pane.rows.delete(key);
      }
      const measured = [];
      for (const p of positions) {
        let row = pane.rows.get(p.key);
        if (!row) {
          const card = pane.doc.createElement('button'); card.type = 'button'; card.className = 'mn-bubble';
          const label = pane.doc.createElement('span'); label.className = 'mn-label';
          const body = pane.doc.createElement('span'); body.className = 'mn-comment';
          card.append(label, body); card.title = '点击定位原批注；在原批注中修改文字';
          card.addEventListener('click', () => Promise.resolve(pane.reader.navigate({ annotationID: p.a.id })).catch(e => this.z.logError(e)));
          const path = pane.doc.createElementNS(NS, 'path');
          const dot = pane.doc.createElementNS(NS, 'circle'); dot.setAttribute('r', '2.5');
          pane.svg.append(path, dot); pane.root.append(card);
          row = { card, label, body, path, dot }; pane.rows.set(p.key, row);
        }
        const text = plainComment(pane.doc, p.a.comment);
        if (row.body.textContent !== text) row.body.textContent = text;
        row.label.textContent = p.key.endsWith(':1') ? '批注 · 续页' : '批注';
        const color = /^#[0-9a-f]{6}$/i.test(p.a.color || '') ? p.a.color : '#d54d69';
        row.card.style.setProperty('--mn-color', color); row.path.setAttribute('stroke', color); row.dot.setAttribute('fill', color);
        row.card.classList.toggle('mn-selected', state.selectedAnnotationIDs?.includes(p.a.id));
        row.card.style.visibility = 'hidden'; row.path.style.display = 'none'; row.dot.style.display = 'none';
        if (readingMode || !text) continue;
        const g = this.geometry(pane, p);
        if (!g) continue;
        const width = Math.min(248, Math.max(80, pane.root.clientWidth * .34 - 24));
        row.card.style.width = width + 'px';
        measured.push({ ...g, key: p.key, height: row.card.offsetHeight || 60, width, row });
      }
      let visible = 0;
      for (const item of stack(measured)) {
        const { row } = item;
        // Never pin callouts to the top when their source scrolls away.
        if (item.y < item.clipTop || item.y > item.clipBottom || item.x < item.frameLeft || item.x > item.frameRight) continue;
        const left = Math.min(item.right + 18, pane.root.clientWidth - item.width - 12);
        row.card.style.left = left + 'px'; row.card.style.top = item.top + 'px'; row.card.style.visibility = 'visible';
        const targetY = item.top + 16, elbow = Math.max(item.x + 4, left - 12);
        row.path.setAttribute('d', `M ${item.x} ${item.y} L ${elbow} ${item.y} L ${left} ${targetY}`);
        row.dot.setAttribute('cx', item.x); row.dot.setAttribute('cy', item.y);
        row.path.style.display = ''; row.dot.style.display = ''; visible++;
      }
      pane.message.textContent = readingMode ? '切回 PDF 页面视图可显示连线批注'
        : positions.length === 0 ? '给高亮或下划线添加文字备注后，会显示连线批注'
          : !measured.length ? '正在等待 PDF 页面坐标…' : '';
      pane.message.hidden = !pane.message.textContent;
    }
    detach(reader) {
      const pane = this.panes.get(reader); if (!pane) return;
      try {
        for (const remove of pane.bindings) remove();
        if (pane.raf !== null) pane.win.cancelAnimationFrame(pane.raf);
        pane.win.removeEventListener('resize', pane.schedule);
        pane.root.remove(); pane.style.remove(); pane.doc.querySelectorAll('.mn-toggle').forEach(b => b.remove());
        pane.doc.body.classList.remove('mn-callouts-open');
      } catch { /* Closed reader. */ }
      this.panes.delete(reader);
    }
    stop() {
      this.running = false; if (this.timer) clearInterval(this.timer);
      this.z.Reader.unregisterEventListener('renderToolbar', this.onToolbar);
      for (const reader of [...this.panes.keys()]) this.detach(reader);
    }
  }
  scope.MarginNotes = MarginNotes;
  if (typeof module !== 'undefined') module.exports = { MarginNotes, plainComment, placements, stack };
})(typeof __marginNotesScope !== 'undefined' ? __marginNotesScope : globalThis);
