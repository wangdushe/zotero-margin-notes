var marginNotes;
var pluginScope;
var startupGeneration = 0;

function startup({ id, rootURI }) {
  const generation = ++startupGeneration;
  // Zotero awaits plugin startup; do not make it wait for its own UI readiness.
  // Pass an explicit export target: loadSubScript's target is not necessarily
  // the object returned by globalThis inside the loaded script.
  pluginScope = { Zotero, Services, setInterval, clearInterval };
  pluginScope.__marginNotesScope = pluginScope;
  Services.scriptloader.loadSubScriptWithOptions(rootURI + 'callouts.js', {
    target: pluginScope,
    ignoreCache: true
  });
  if (typeof pluginScope.MarginNotes !== 'function') {
    throw new Error('Margin Notes: callouts.js did not export its constructor');
  }
  const css = Zotero.File.getContentsFromURL(rootURI + 'callouts.css');
  const Constructor = pluginScope.MarginNotes;
  Zotero.uiReadyPromise.then(() => {
    if (generation !== startupGeneration) return;
    marginNotes = new Constructor(Zotero, css, id);
    marginNotes.start();
  }).catch(error => {
    Zotero.logError('Margin Notes startup failed: ' + error);
    marginNotes?.stop();
  });
}

function shutdown() {
  startupGeneration++;
  marginNotes?.stop();
  marginNotes = null;
  pluginScope = null;
}

function install() {}
function uninstall() {}
